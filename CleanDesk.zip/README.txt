CleanDesk

Descrição:
CleanDesk é um programa para organizar automaticamente sua pasta de Downloads, separando arquivos em pastas por tipo (imagens, documentos, executáveis, etc). Pode ser executado manualmente ou agendado para rodar automaticamente.

Como usar:
1. Extraia o conteúdo do arquivo ZIP em uma pasta no seu computador.
2. Execute o arquivo 'gui_scheduler.exe' para abrir a interface gráfica do agendador.
3. Escolha a frequência de organização desejada ou execute a limpeza manualmente.
4. O programa organizará sua pasta de Downloads, criando subpastas conforme o tipo dos arquivos.

Logs:
- Os logs ficam na pasta 'logs' ao lado do executável.
- Cada arquivo de log corresponde a um mês.
- O programa mantém logs dos últimos 3 meses, apagando os mais antigos automaticamente.

Requisitos:
- Windows 10 ou superior.
- Nenhuma instalação adicional é necessária.

Contato:
Raian Leite
Email: raianleite97@gmail.com

Obrigado por usar o CleanDesk!
